# Rscripts
Repository of R scripts provided in BAIS:4150 at the University of Iowa 

These scripts belong to Emmanuel Peters and are not my own
